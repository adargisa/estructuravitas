package com.example.estructuravistas;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {
    EditText usuario;
    EditText contraseña;
    String usuario_cadena,contraseña_cadena;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        usuario = (EditText) findViewById(R.id.usuario);
        contraseña = (EditText) findViewById(R.id.contraseña);

        usuario_cadena = usuario.getText().toString();
        contraseña_cadena = contraseña.getText().toString();

    }

    public void accederProducto(View view) {
        Intent intent = new Intent(this,ProductoActivity.class);


        intent.putExtra("usuario",usuario_cadena);
        intent.putExtra("contraseña",contraseña_cadena);
        
        startActivity(intent);
    }
}